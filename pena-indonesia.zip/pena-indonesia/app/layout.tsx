import './globals.css'; import Link from 'next/link';
export const metadata={title:'Pena Indonesia',description:'Platform novel Indonesia'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="id"><body><header><Link href="/" className="logo">Pena Indonesia</Link><nav><Link href="/novel">Novel</Link><Link href="/login">Masuk</Link></nav></header><main>{children}</main><footer>Pena Indonesia · Platform novel Indonesia</footer></body></html>}
