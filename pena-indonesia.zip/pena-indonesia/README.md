# Pena Indonesia
Starter Next.js untuk platform novel Indonesia. Siap dikembangkan dengan Supabase dan Vercel.
